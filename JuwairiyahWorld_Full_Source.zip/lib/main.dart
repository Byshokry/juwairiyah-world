import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';

const teal = Color(0xFF159D9A);
const navy = Color(0xFF24434B);
const pale = Color(0xFFF4FBFA);

void main() => runApp(const JuwairiyahWorld());

class WordCard {
  final String letter, letterName, word, emoji;
  final bool suggested;
  const WordCard(this.letter, this.letterName, this.word, this.emoji, {this.suggested = false});
}

const cards = <WordCard>[
  WordCard('أ','ألف','أسد','🦁'), WordCard('ب','باء','باب','🚪'),
  WordCard('ت','تاء','تفاحة','🍎'), WordCard('ث','ثاء','ثعلب','🦊'),
  WordCard('ج','جيم','جمل','🐪'), WordCard('ح','حاء','حوت','🐳'),
  WordCard('خ','خاء','خبز','🍞'), WordCard('د','دال','دب','🐻'),
  WordCard('ذ','ذال','ذئب','🐺'), WordCard('ر','راء','ريشة','🪶'),
  WordCard('ز','زاي','زرافة','🦒'), WordCard('س','سين','سمكة','🐟'),
  WordCard('ش','شين','شجرة','🌳'), WordCard('ص','صاد','صقر','🦅', suggested:true),
  WordCard('ض','ضاد','ضفدعة','🐸'), WordCard('ط','طاء','طائرة','✈️'),
  WordCard('ظ','ظاء','ظرف','✉️'), WordCard('ع','عين','عنب','🍇'),
  WordCard('غ','غين','غزالة','🦌'), WordCard('ف','فاء','فراشة','🦋'),
  WordCard('ق','قاف','قطة','🐱'), WordCard('ك','كاف','كتاب','📘'),
  WordCard('ل','لام','ليمون','🍋'), WordCard('م','ميم','موزة','🍌'),
  WordCard('ن','نون','نجمة','⭐'), WordCard('هـ','هاء','هدية','🎁'),
  WordCard('و','واو','وردة','🌹'), WordCard('ي','ياء','يد','✋'),
];

class JuwairiyahWorld extends StatelessWidget {
  const JuwairiyahWorld({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'عالم جويرية', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3:true, colorScheme: ColorScheme.fromSeed(seedColor:teal), scaffoldBackgroundColor:pale, fontFamily:'sans-serif'),
    home: const HomePage(),
  );
}

class Voice {
  static final FlutterTts tts = FlutterTts();
  static Future<void> say(String text) async {
    try {
      await tts.stop();
      await tts.setLanguage('ar');
      await tts.setSpeechRate(0.38);
      await tts.setPitch(1.08);
      await tts.speak(text);
    } catch (_) {}
  }
}

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState()=>_HomePageState(); }
class _HomePageState extends State<HomePage> {
  int stars=0;
  @override void initState(){super.initState(); _load();}
  Future<void> _load() async { final p=await SharedPreferences.getInstance(); if(mounted)setState(()=>stars=p.getInt('stars')??0); }
  @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    const SizedBox(height:16), const Text('عالم جويرية',textAlign:TextAlign.center,style:TextStyle(fontSize:32,fontWeight:FontWeight.w900,color:navy)),
    const Text('نتعلّم ونلعب ونكتشف معًا',textAlign:TextAlign.center,style:TextStyle(fontSize:17,color:Colors.black54)),
    const SizedBox(height:14), Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:const Color(0xFFFFF0C9),borderRadius:BorderRadius.circular(20)),child:Text('⭐ نجوم جويرية: $stars',textAlign:TextAlign.center,style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold,color:navy))),
    const SizedBox(height:18), Expanded(child:GridView.count(crossAxisCount:2,mainAxisSpacing:12,crossAxisSpacing:12,children:[
      _Tile('عالم الحروف','الحروف والكلمات','🔤',const Color(0xFFDDF4EF),()=>_go(const LettersPage())),
      _Tile('اسمع واكتشف','أسماء وأصوات','🔊',const Color(0xFFE1F0FA),()=>_go(const SoundsPage())),
      _Tile('اختبر ذاكرتك','اختاري الحرف الصحيح','🧩',const Color(0xFFFFEAD9),()=>_go(const QuizPage())),
      _Tile('بطاقاتي الأصلية','صور البطاقات التي أرسلتِها','🖼️',const Color(0xFFF6E6F2),()=>_go(const GalleryPage())),
    ])), const Text('اللعب بهدوء… وكل محاولة تعلّم جديد 💚',textAlign:TextAlign.center,style:TextStyle(color:Colors.black45)),
  ]))));
  void _go(Widget page)=>Navigator.push(context,MaterialPageRoute(builder:(_)=>page));
}
class _Tile extends StatelessWidget {
  final String title,sub,emoji; final Color color; final VoidCallback onTap;
  const _Tile(this.title,this.sub,this.emoji,this.color,this.onTap);
  @override Widget build(BuildContext context)=>Material(color:color,borderRadius:BorderRadius.circular(25),child:InkWell(onTap:onTap,borderRadius:BorderRadius.circular(25),child:Padding(padding:const EdgeInsets.all(12),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text(emoji,style:const TextStyle(fontSize:46)),const SizedBox(height:8),Text(title,textAlign:TextAlign.center,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900,color:navy)),const SizedBox(height:4),Text(sub,textAlign:TextAlign.center,style:const TextStyle(fontSize:12,color:Colors.black54))]))));
}

class LettersPage extends StatelessWidget { const LettersPage({super.key});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('حروفي')),body:GridView.builder(padding:const EdgeInsets.all(14),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:3,crossAxisSpacing:10,mainAxisSpacing:10,childAspectRatio:.9),itemCount:cards.length,itemBuilder:(c,i){final x=cards[i];return Material(color:Colors.white,borderRadius:BorderRadius.circular(20),child:InkWell(borderRadius:BorderRadius.circular(20),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>LetterPage(card:x))),child:Padding(padding:const EdgeInsets.all(7),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text(x.letter,style:const TextStyle(fontSize:42,fontWeight:FontWeight.w900,color:teal)),Text(x.word,style:const TextStyle(fontSize:14,fontWeight:FontWeight.bold,color:navy)),if(x.suggested)const Text('مثال مقترح',style:TextStyle(fontSize:9,color:Colors.orange))]))));}));
}
class LetterPage extends StatelessWidget { final WordCard card; const LetterPage({super.key,required this.card});
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text('حرف ${card.letter}')),body:Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.stretch,children:[
   Text(card.letter,textAlign:TextAlign.center,style:const TextStyle(fontSize:130,fontWeight:FontWeight.w900,color:teal)),
   Text(card.letterName,textAlign:TextAlign.center,style:const TextStyle(fontSize:26,color:navy,fontWeight:FontWeight.bold)),
   const SizedBox(height:16),Container(padding:const EdgeInsets.all(22),
   decoration:BoxDecoration(color:const Color(0xFFFFF0DA),borderRadius:BorderRadius.circular(28)),child:Column(children:[Text(card.emoji,style:const TextStyle(fontSize:100)),Text(card.word,style:const TextStyle(fontSize:32,fontWeight:FontWeight.w900,color:navy)),if(card.suggested)const Text('كلمة مقترحة لإكمال الحروف، وليست ضمن الكلمات المؤكدة',textAlign:TextAlign.center,style:TextStyle(color:Colors.deepOrange,fontSize:12))])),
   const SizedBox(height:22),FilledButton.icon(onPressed:()=>Voice.say(card.letterName),icon:const Icon(Icons.volume_up),label:const Text('اسمع اسم الحرف'),style:FilledButton.styleFrom(minimumSize:const Size.fromHeight(54),backgroundColor:teal)),
   const SizedBox(height:10),OutlinedButton.icon(onPressed:()=>Voice.say(card.word),icon:const Icon(Icons.hearing),label:const Text('اسمع الكلمة'),style:OutlinedButton.styleFrom(minimumSize:const Size.fromHeight(52),foregroundColor:teal)),
 ]))));
}

class SoundsPage extends StatelessWidget { const SoundsPage({super.key});
 static const sounds=[('🚗','السيارة'),('🚑','سيارة الإسعاف'),('🚂','القطار'),('✈️','الطائرة'),('🚲','جرس الدراجة'),('🐈','القطة'),('🐕','الكلب'),('🐄','البقرة'),('🐦','العصفور'),('🐸','الضفدعة'),('🦁','الأسد'),('🐝','النحلة'),('🌧️','المطر'),('⛈️','الرعد'),('🌬️','الرياح'),('🌊','الأمواج'),('🔔','جرس الباب'),('☎️','الهاتف'),('⏰','الساعة'),('💧','الماء'),('🌀','المروحة')];
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('اسمع واكتشف')),body:Column(children:[Container(margin:const EdgeInsets.all(12),padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:const Color(0xFFFFF0D9),borderRadius:BorderRadius.circular(16)),child:const Text('اضغطي على البطاقة لسماع اسم الشيء. التسجيلات الطبيعية الحقيقية ستضاف في تحديث مكتبة الأصوات.',textAlign:TextAlign.center,style:TextStyle(color:navy))),Expanded(child:GridView.builder(padding:const EdgeInsets.all(12),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:3,crossAxisSpacing:10,mainAxisSpacing:10),itemCount:sounds.length,itemBuilder:(c,i)=>Material(color:Colors.white,borderRadius:BorderRadius.circular(18),child:InkWell(borderRadius:BorderRadius.circular(18),onTap:()=>Voice.say(sounds[i].$2),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text(sounds[i].$1,style:const TextStyle(fontSize:38)),Text(sounds[i].$2,textAlign:TextAlign.center,style:const TextStyle(fontWeight:FontWeight.bold,color:navy,fontSize:12)),const Icon(Icons.volume_up,color:teal)])))))]));
}

class QuizPage extends StatefulWidget { const QuizPage({super.key}); @override State<QuizPage> createState()=>_QuizPageState(); }
class _QuizPageState extends State<QuizPage>{final rnd=Random();late WordCard target;late List<WordCard> choices;int points=0;String? message;
 @override void initState(){super.initState();_next();}
 void _next(){target=cards[rnd.nextInt(cards.length)];final pool=cards.where((x)=>x.letter!=target.letter).toList()..shuffle(rnd);choices=([target,...pool.take(3)]..shuffle(rnd));message=null;}
 Future<void> _answer(WordCard x)async{if(x.letter==target.letter){points++;final p=await SharedPreferences.getInstance();final old=p.getInt('stars')??0;await p.setInt('stars',old+1);setState(()=>message='أحسنتِ يا جويرية! ⭐');await Voice.say('أحسنت يا جويرية');}else{setState(()=>message='محاولة جميلة، هيا نحاول مرة أخرى');await Voice.say('حاولي مرة أخرى');}}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('اختاري الحرف الصحيح')),body:Padding(padding:const EdgeInsets.all(18),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Text('أي حرف يبدأ به اسم هذه الصورة؟',textAlign:TextAlign.center,style:TextStyle(fontSize:21,fontWeight:FontWeight.bold,color:navy)),const SizedBox(height:18),Text(target.emoji,style:const TextStyle(fontSize:100)),Text(target.word,style:const TextStyle(fontSize:30,fontWeight:FontWeight.w900,color:teal)),IconButton(onPressed:()=>Voice.say(target.word),icon:const Icon(Icons.volume_up,size:34,color:teal)),const SizedBox(height:20),Wrap(spacing:12,runSpacing:12,alignment:WrapAlignment.center,children:choices.map((x)=>SizedBox(width:130,height:100,child:FilledButton(onPressed:()=>_answer(x),style:FilledButton.styleFrom(backgroundColor:const Color(0xFFDDF2EC),foregroundColor:navy,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(20))),child:Text(x.letter,style:const TextStyle(fontSize:46,fontWeight:FontWeight.w900))))).toList()),if(message!=null)Padding(padding:const EdgeInsets.all(16),child:Text(message!,style:const TextStyle(fontSize:19,fontWeight:FontWeight.bold,color:teal))),const SizedBox(height:12),FilledButton(onPressed:()=>setState(_next),child:const Text('سؤال جديد'))])));
}

class GalleryPage extends StatelessWidget { const GalleryPage({super.key});
 static const photos=['cards_1.webp','cards_2.webp','cards_3.webp','cards_4.webp','cards_5.webp','cards_6.webp'];
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('بطاقاتي الأصلية')),body:ListView(padding:const EdgeInsets.all(12),children:[const Text('هذه صور البطاقات التي أرسلتها الأسرة، محفوظة داخل التطبيق للرجوع إليها.',textAlign:TextAlign.center,style:TextStyle(color:navy,fontSize:16)),const SizedBox(height:12),...photos.asMap().entries.map((e)=>Padding(padding:const EdgeInsets.only(bottom:14),child:ClipRRect(borderRadius:BorderRadius.circular(18),child:Image.asset('assets/reference/${e.value}',fit:BoxFit.contain))))]));
}
