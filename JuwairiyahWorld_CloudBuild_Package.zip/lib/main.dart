import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const JuwairiyahApp());

const teal = Color(0xFF218F89);
const ink = Color(0xFF29434A);
const cream = Color(0xFFFFFCF5);

class LetterData {
  final String letter, name, word, emoji, description;
  const LetterData(this.letter, this.name, this.word, this.emoji, this.description);
}

const letters = <LetterData>[
  LetterData('أ', 'ألف', 'أسد', '🦁', 'ألف مثل أسد'),
  LetterData('ب', 'باء', 'باب', '🚪', 'باء مثل باب'),
  LetterData('ت', 'تاء', 'تفاحة', '🍎', 'تاء مثل تفاحة'),
  LetterData('ث', 'ثاء', 'ثعلب', '🦊', 'ثاء مثل ثعلب'),
  LetterData('ج', 'جيم', 'جمل', '🐪', 'جيم مثل جمل'),
  LetterData('ح', 'حاء', 'حوت', '🐳', 'حاء مثل حوت'),
  LetterData('خ', 'خاء', 'خبز', '🍞', 'خاء مثل خبز'),
  LetterData('د', 'دال', 'دب', '🐻', 'دال مثل دب'),
  LetterData('ذ', 'ذال', 'ذئب', '🐺', 'ذال مثل ذئب'),
  LetterData('ر', 'راء', 'ريشة', '🪶', 'راء مثل ريشة'),
  LetterData('ز', 'زاي', 'زرافة', '🦒', 'زاي مثل زرافة'),
  LetterData('س', 'سين', 'سمكة', '🐟', 'سين مثل سمكة'),
  LetterData('ش', 'شين', 'شجرة', '🌳', 'شين مثل شجرة'),
  LetterData('ص', 'صاد', 'صقر', '🦅', 'صاد مثل صقر — كلمة مقترحة وليست ضمن الكلمات المؤكدة'),
  LetterData('ض', 'ضاد', 'ضفدعة', '🐸', 'ضاد مثل ضفدعة'),
  LetterData('ط', 'طاء', 'طائرة', '✈️', 'طاء مثل طائرة'),
  LetterData('ظ', 'ظاء', 'ظرف', '✉️', 'ظاء مثل ظرف'),
  LetterData('ع', 'عين', 'عنب', '🍇', 'عين مثل عنب'),
  LetterData('غ', 'غين', 'غزالة', '🦌', 'غين مثل غزالة'),
  LetterData('ف', 'فاء', 'فراشة', '🦋', 'فاء مثل فراشة'),
  LetterData('ق', 'قاف', 'قطة', '🐱', 'قاف مثل قطة'),
  LetterData('ك', 'كاف', 'كتاب', '📘', 'كاف مثل كتاب'),
  LetterData('ل', 'لام', 'ليمون', '🍋', 'لام مثل ليمون'),
  LetterData('م', 'ميم', 'موزة', '🍌', 'ميم مثل موزة'),
  LetterData('ن', 'نون', 'نجمة', '⭐', 'نون مثل نجمة'),
  LetterData('هـ', 'هاء', 'هدية', '🎁', 'هاء مثل هدية'),
  LetterData('و', 'واو', 'وردة', '🌹', 'واو مثل وردة'),
  LetterData('ي', 'ياء', 'يد', '✋', 'ياء مثل يد'),
];

class JuwairiyahApp extends StatelessWidget {
  const JuwairiyahApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'عالم جويرية',
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: cream,
      colorScheme: ColorScheme.fromSeed(seedColor: teal, surface: cream),
      fontFamily: 'sans-serif',
      appBarTheme: const AppBarTheme(backgroundColor: cream, foregroundColor: ink, centerTitle: true),
    ),
    home: const HomeScreen(),
  );
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const SizedBox(height: 18),
        const Text('أهلًا يا جويرية! 👋', textAlign: TextAlign.center,
          style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, color: ink)),
        const SizedBox(height: 8),
        const Text('هيا نكتشف ونتعلّم معًا', textAlign: TextAlign.center,
          style: TextStyle(fontSize: 17, color: Colors.black54)),
        const SizedBox(height: 28),
        Expanded(child: GridView.count(crossAxisCount: 2, crossAxisSpacing: 14, mainAxisSpacing: 14,
          children: [
            _WorldTile(title: 'عالم الحروف', subtitle: 'حروف وكلمات', emoji: '🔤', color: const Color(0xFFE0F1E8),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LettersScreen()))),
            _WorldTile(title: 'اسمع واكتشف', subtitle: 'أصوات من حولنا', emoji: '🔊', color: const Color(0xFFE0F0F6),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SoundsScreen()))),
            const _WorldTile(title: 'عالم الحيوانات', subtitle: 'نتعرّف على الكائنات', emoji: '🐾', color: Color(0xFFFFEEDB)),
            const _WorldTile(title: 'ألوان وأشكال', subtitle: 'نرى ونسمّي', emoji: '🎨', color: Color(0xFFF8E7EF)),
          ])),
        const Text('اللعب معًا أجمل من الاختبار 💚', textAlign: TextAlign.center,
          style: TextStyle(color: Colors.black45, fontSize: 13)),
      ]),
    )),
  );
}

class _WorldTile extends StatelessWidget {
  final String title, subtitle, emoji;
  final Color color;
  final VoidCallback? onTap;
  const _WorldTile({required this.title, required this.subtitle, required this.emoji, required this.color, this.onTap});
  @override
  Widget build(BuildContext context) => Material(
    color: color, borderRadius: BorderRadius.circular(26),
    child: InkWell(borderRadius: BorderRadius.circular(26), onTap: onTap,
      child: Padding(padding: const EdgeInsets.all(14), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text(emoji, style: const TextStyle(fontSize: 48)),
        const SizedBox(height: 10),
        Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: ink)),
        const SizedBox(height: 5),
        Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: Colors.black54)),
      ]))),
  );
}

class LettersScreen extends StatelessWidget {
  const LettersScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('حروفي')),
    body: GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 12, mainAxisSpacing: 12),
      itemCount: letters.length,
      itemBuilder: (context, i) {
        final item = letters[i];
        return Material(color: const Color(0xFFE4F2EF), borderRadius: BorderRadius.circular(22),
          child: InkWell(borderRadius: BorderRadius.circular(22),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LetterScreen(item: item))),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(item.letter, style: const TextStyle(fontSize: 48, fontWeight: FontWeight.w900, color: teal)),
              Text(item.name, style: const TextStyle(fontSize: 13, color: ink)),
            ])));
      },
    ),
  );
}

class LetterScreen extends StatefulWidget {
  final LetterData item;
  const LetterScreen({super.key, required this.item});
  @override
  State<LetterScreen> createState() => _LetterScreenState();
}

class _LetterScreenState extends State<LetterScreen> {
  final player = AudioPlayer();
  @override
  void dispose() { player.dispose(); super.dispose(); }
  Future<void> play(String path) async {
    try { await player.stop(); await player.play(AssetSource(path)); }
    catch (_) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('سيُضاف التسجيل الصوتي في مرحلة تجهيز مكتبة الأصوات.'))); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('نتعرّف على الحرف')),
    body: Padding(padding: const EdgeInsets.all(22), child: Column(
      mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(widget.item.letter, textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 112, fontWeight: FontWeight.w900, color: teal)),
        Text(widget.item.name, textAlign: TextAlign.center, style: const TextStyle(fontSize: 24, color: ink, fontWeight: FontWeight.bold)),
        const SizedBox(height: 28),
        Container(padding: const EdgeInsets.all(24), decoration: BoxDecoration(color: const Color(0xFFFFF0DA), borderRadius: BorderRadius.circular(28)),
          child: Column(children: [
            Text(widget.item.emoji, style: const TextStyle(fontSize: 90)),
            const SizedBox(height: 8),
            Text(widget.item.word, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: ink)),
          ])),
        const SizedBox(height: 22),
        FilledButton.icon(onPressed: () => play('letters/${widget.item.letter}.mp3'),
          icon: const Icon(Icons.volume_up_rounded), label: const Text('استمع إلى اسم الحرف', style: TextStyle(fontSize: 17)),
          style: FilledButton.styleFrom(backgroundColor: teal, minimumSize: const Size.fromHeight(58))),
        const SizedBox(height: 10),
        OutlinedButton.icon(onPressed: () => play('words/${widget.item.word}.mp3'),
          icon: const Icon(Icons.hearing_rounded), label: const Text('استمع إلى الكلمة', style: TextStyle(fontSize: 17)),
          style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(54), foregroundColor: teal)),
      ],
    )),
  );
}

class SoundsScreen extends StatelessWidget {
  const SoundsScreen({super.key});
  static const items = [
    ('🚗', 'السيارة', 'صوت محرك السيارة'),
    ('🚆', 'القطار', 'صوت القطار وصفارته'),
    ('✈️', 'الطائرة', 'صوت محركات الطائرة'),
    ('🚲', 'الدراجة', 'جرس الدراجة'),
    ('🐈', 'القطة', 'مواء القطة'),
    ('🐕', 'الكلب', 'نباح الكلب'),
    ('🐄', 'البقرة', 'خوار البقرة'),
    ('🐝', 'النحلة', 'طنين النحلة'),
    ('🌧️', 'المطر', 'صوت المطر'),
    ('🔔', 'جرس الباب', 'صوت جرس الباب'),
  ];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('اسمع واكتشف')),
    body: ListView.separated(padding: const EdgeInsets.all(16), itemCount: items.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, i) => Container(
        decoration: BoxDecoration(color: const Color(0xFFE7F1F3), borderRadius: BorderRadius.circular(20)),
        child: ListTile(contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
          leading: Text(items[i].$1, style: const TextStyle(fontSize: 38)),
          title: Text(items[i].$2, style: const TextStyle(fontWeight: FontWeight.bold, color: ink)),
          subtitle: Text(items[i].$3),
          trailing: IconButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('سيُضاف التسجيل الطبيعي لهذا الصوت في مرحلة تجهيز مكتبة الأصوات.'))),
            icon: const Icon(Icons.volume_up_rounded, color: teal, size: 30)),
        ),
      )),
  );
}
