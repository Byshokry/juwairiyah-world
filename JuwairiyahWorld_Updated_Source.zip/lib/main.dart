import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:shared_preferences/shared_preferences.dart';

const teal = Color(0xFF159D9A), navy = Color(0xFF24434B), pale = Color(0xFFF4FBFA);
void main() => runApp(const JuwairiyahWorld());

class LetterData { final String glyph, name, word, picture; const LetterData(this.glyph,this.name,this.word,this.picture); }
const data = <LetterData>[
 LetterData('أ','ألف','أسد','🦁'), LetterData('ب','باء','باب','🚪'), LetterData('ت','تاء','تفاحة','🍎'), LetterData('ث','ثاء','ثعلب','🦊'),
 LetterData('ج','جيم','جمل','🐪'), LetterData('ح','حاء','حوت','🐳'), LetterData('خ','خاء','خبز','🍞'), LetterData('د','دال','دب','🐻'),
 LetterData('ذ','ذال','ذئب','🐺'), LetterData('ر','راء','ريشة','🪶'), LetterData('ز','زاي','زرافة','🦒'), LetterData('س','سين','سمكة','🐟'),
 LetterData('ش','شين','شجرة','🌳'), LetterData('ص','صاد','صقر','🦅'), LetterData('ض','ضاد','ضفدعة','🐸'), LetterData('ط','طاء','طائرة','✈️'),
 LetterData('ظ','ظاء','ظرف','✉️'), LetterData('ع','عين','عنب','🍇'), LetterData('غ','غين','غزالة','🦌'), LetterData('ف','فاء','فراشة','🦋'),
 LetterData('ق','قاف','قطة','🐱'), LetterData('ك','كاف','كتاب','📘'), LetterData('ل','لام','ليمون','🍋'), LetterData('م','ميم','موزة','🍌'),
 LetterData('ن','نون','نجمة','⭐'), LetterData('هـ','هاء','هدية','🎁'), LetterData('و','واو','وردة','🌹'), LetterData('ي','ياء','يد','✋'),
];

class SoundClip { final String label, emoji, file, source; const SoundClip(this.label,this.emoji,this.file,this.source); }
const soundClips = <SoundClip>[
 SoundClip('فأر','🐀','u_3yocsblk00-rat-squeaking-sound-effecthd-570216.mp3','تسجيل 1'),
 SoundClip('ثعلب','🦊','l3hrja-fox-calling-243999.mp3','تسجيل 1'),
 SoundClip('ديك','🐓','wings_of_freedom-chicken-sound-402826.mp3','تسجيل 1'),
 SoundClip('حركة الماء','💦','freesound_community-fish-splashing-release-2-40947.mp3','تسجيل 1'),
 SoundClip('قطار','🚆','tanweraman-train-horn-337875.mp3','تسجيل 1'),
 SoundClip('سيارة','🚗','universfield-double-car-honk-352443.mp3','تسجيل 1'),
 SoundClip('طائرة','✈️','southbaysounds-airplane-taking-off-214796.mp3','تسجيل 1'),
 SoundClip('خروف','🐑','u_ckpn52p1rm-sheep-baaing-554226.mp3','تسجيل 1'),
 SoundClip('بطة','🦆','sondangsirait419-bebek-220068.mp3','تسجيل 1'),
 SoundClip('جمل','🐪','mollyroselee-camel-sound-effects-still-pending-for-weeks-540233.mp3','تسجيل 1'),
 SoundClip('أسد','🦁','soundzee-lion-snarl-growl-354324.mp3','تسجيل 1'),
 SoundClip('خروف','🐑','mixkit-sheep-sounds-1741.wav','تسجيل 2'),
 SoundClip('حوت','🐋','freesound_community-whale-45996.mp3','تسجيل 1'),
 SoundClip('دب','🐻','efrein_amato-bear-growl-fx-175165.mp3','تسجيل 1'),
 SoundClip('ثعبان','🐍','freesound_community-snake-hissing-6092.mp3','تسجيل 1'),
 SoundClip('ماعز','🐐','soumages-goat-sound-403453.mp3','تسجيل 1'),
 SoundClip('خروف','🐑','universfield-sheep-bleat-122256.mp3','تسجيل 3'),
 SoundClip('ضفدع','🐸','u_dtw7a5lpx2-frog-sound-568831.mp3','تسجيل 1'),
 SoundClip('فيل','🐘','freesound_community-elephant-trumpets-growls-6047.mp3','تسجيل 1'),
 SoundClip('بقرة','🐄','mixkit-cow-moo-in-the-barn-1751.wav','تسجيل 1'),
 SoundClip('قطة','🐱','mixkit-cartoon-kitty-begging-meow-92.wav','تسجيل 1'),
 SoundClip('ديك','🐓','mixkit-rooster-crowing-in-the-morning-2462.wav','تسجيل 2'),
 SoundClip('قطة','🐱','mixkit-sweet-kitty-meow-93.wav','تسجيل 2'),
 SoundClip('كلب','🐕','mixkit-dog-barking-twice-1.wav','تسجيل 1'),
 SoundClip('قطة','🐱','mixkit-sphinx-cat-purr-and-quiet-growl-3092.wav','تسجيل 3'),
 SoundClip('طائر','🐦','mixkit-tropical-bird-squeak-27.wav','تسجيل 1'),
 SoundClip('صرصور','🦗','mixkit-single-cricket-screech-1780.wav','تسجيل 1'),
 SoundClip('حصان','🐎','mixkit-scared-horse-neighing-85.wav','تسجيل 1'),
 SoundClip('كلب','🐕','mixkit-horde-of-barking-dogs-60.wav','تسجيل 2'),
 SoundClip('ذبابة','🪰','mixkit-large-fly-buzzing-41.wav','تسجيل 1'),
 SoundClip('ديك','🐓','mixkit-cock-cry-1761.wav','تسجيل 3'),
 SoundClip('غراب','🐦‍⬛','mixkit-crow-shor-crowing-316.wav','تسجيل 1'),
 SoundClip('نحلة','🐝','mixkit-big-bee-hard-flying-sound-42.wav','تسجيل 1'),
 SoundClip('قرد','🐒','mixkit-monkey-excited-screech-105.wav','تسجيل 1'),
 SoundClip('بقرة','🐄','mixkit-multiple-moo-in-the-barn-1750.wav','تسجيل 2'),
];

class AudioHub {
 static final AudioPlayer player = AudioPlayer();
 static final FlutterTts tts = FlutterTts();
 static Future<void> sound(String file) async { await tts.stop(); await player.stop(); await player.play(AssetSource('audio/sounds/$file')); }
 static Future<void> praise(int count) async { await tts.stop(); await player.stop(); final f = count % 3 == 0 ? 'audio/rewards/praise_jouri.m4a' : 'audio/rewards/praise_juwairiyah.m4a'; await player.play(AssetSource(f)); }
 static Future<void> say(String s) async { await player.stop(); await tts.setLanguage('ar'); await tts.setSpeechRate(0.42); await tts.setPitch(1.0); await tts.speak(s); }
}

class JuwairiyahWorld extends StatelessWidget { const JuwairiyahWorld({super.key}); @override Widget build(BuildContext context)=>MaterialApp(title:'عالم جويرية',debugShowCheckedModeBanner:false,theme:ThemeData(useMaterial3:true,colorScheme:ColorScheme.fromSeed(seedColor:teal),scaffoldBackgroundColor:pale,fontFamily:'sans-serif'),home:const HomePage()); }
class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState()=>_HomePageState(); }
class _HomePageState extends State<HomePage> { int stars=0; @override void initState(){super.initState();SharedPreferences.getInstance().then((p){if(mounted)setState(()=>stars=p.getInt('stars')??0);});}
 @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:Padding(padding:const EdgeInsets.all(18),child:Column(children:[const SizedBox(height:18),const Text('عالم جويرية',style:TextStyle(fontSize:32,fontWeight:FontWeight.w900,color:navy)),const Text('نتعلّم ونلعب ونكتشف معًا',style:TextStyle(fontSize:17,color:Colors.black54)),const SizedBox(height:14),Container(width:double.infinity,padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:const Color(0xFFFFF0C9),borderRadius:BorderRadius.circular(20)),child:Text('⭐ نجوم جويرية: $stars',textAlign:TextAlign.center,style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold,color:navy))),const SizedBox(height:18),Expanded(child:GridView.count(crossAxisCount:2,mainAxisSpacing:12,crossAxisSpacing:12,children:[_Tile('الحروف','حرف واحد في كل مرة','🔤',const Color(0xFFDDF4EF),()=>_go(const LettersPage())),_Tile('الكلمات','نتعرف على شكل الكلمة','📖',const Color(0xFFE1F0FA),()=>_go(const WordsPage())),_Tile('الصور','شوفي وتعرفي على الصورة','🖼️',const Color(0xFFF6E6F2),()=>_go(const PicturesPage())),_Tile('الأصوات','اسمعي أصواتًا حقيقية','🔊',const Color(0xFFFFEAD9),()=>_go(const SoundsPage())),_Tile('اختبار الحروف','اختاري الحرف','🧩',const Color(0xFFE9E5FF),()=>_go(const QuizPage(kind:QuizKind.letter))),_Tile('اختبار الكلمات','اختاري الكلمة','📝',const Color(0xFFFFF0C9),()=>_go(const QuizPage(kind:QuizKind.word))),_Tile('اختبار الصور','تعرفي على الصورة','🧠',const Color(0xFFE3F4E7),()=>_go(const QuizPage(kind:QuizKind.picture))),_Tile('اختبار الأصوات','اسمعي واختاري المصدر','🎧',const Color(0xFFFFE4E4),()=>_go(const QuizPage(kind:QuizKind.sound)))])),const Text('اللعب بهدوء… وكل محاولة تعلّم جديد 💚',style:TextStyle(color:Colors.black45))]))));
 void _go(Widget p)=>Navigator.push(context,MaterialPageRoute(builder:(_)=>p)); }
class _Tile extends StatelessWidget { final String title,sub,emoji;final Color color;final VoidCallback onTap;const _Tile(this.title,this.sub,this.emoji,this.color,this.onTap);@override Widget build(BuildContext context)=>Material(color:color,borderRadius:BorderRadius.circular(24),child:InkWell(onTap:onTap,borderRadius:BorderRadius.circular(24),child:Padding(padding:const EdgeInsets.all(10),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text(emoji,style:const TextStyle(fontSize:42)),const SizedBox(height:8),Text(title,textAlign:TextAlign.center,style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900,color:navy)),Text(sub,textAlign:TextAlign.center,style:const TextStyle(fontSize:11,color:Colors.black54))]))));}

class LettersPage extends StatelessWidget { const LettersPage({super.key}); @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('الحروف فقط')),body:GridView.builder(padding:const EdgeInsets.all(14),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:3,crossAxisSpacing:10,mainAxisSpacing:10),itemCount:data.length,itemBuilder:(c,i)=>_PlainCard(text:data[i].glyph,size:48,onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>LetterDetail(item:data[i]))))));}
class LetterDetail extends StatelessWidget { final LetterData item;const LetterDetail({super.key,required this.item});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('حرفي')),body:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text(item.glyph,style:const TextStyle(fontSize:170,fontWeight:FontWeight.w900,color:teal)),FilledButton.icon(onPressed:()=>AudioHub.say(item.name),icon:const Icon(Icons.volume_up),label:const Text('اسمع اسم الحرف'))])));}
class WordsPage extends StatelessWidget { const WordsPage({super.key});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('الكلمات فقط')),body:GridView.builder(padding:const EdgeInsets.all(14),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,crossAxisSpacing:10,mainAxisSpacing:10,childAspectRatio:1.6),itemCount:data.length,itemBuilder:(c,i)=>_PlainCard(text:data[i].word,size:28,onTap:()=>AudioHub.say(data[i].word))));}
class _PlainCard extends StatelessWidget {final String text;final double size;final VoidCallback onTap;const _PlainCard({required this.text,required this.size,required this.onTap});@override Widget build(BuildContext context)=>Material(color:Colors.white,borderRadius:BorderRadius.circular(20),child:InkWell(onTap:onTap,borderRadius:BorderRadius.circular(20),child:Center(child:Text(text,style:TextStyle(fontSize:size,fontWeight:FontWeight.w900,color:teal)))));}
class PicturesPage extends StatelessWidget {
 const PicturesPage({super.key});
 @override Widget build(BuildContext context)=>Scaffold(
  appBar:AppBar(title:const Text('الصور فقط')),
  body:GridView.builder(padding:const EdgeInsets.all(14),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:3,crossAxisSpacing:10,mainAxisSpacing:10),itemCount:data.length,itemBuilder:(c,i)=>Material(color:Colors.white,borderRadius:BorderRadius.circular(20),child:InkWell(borderRadius:BorderRadius.circular(20),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>PictureViewer(initialIndex:i))),child:Center(child:Text(data[i].picture,style:const TextStyle(fontSize:54)))))));
}
class PictureViewer extends StatefulWidget {
 final int initialIndex; const PictureViewer({super.key,required this.initialIndex});
 @override State<PictureViewer> createState()=>_PictureViewerState();
}
class _PictureViewerState extends State<PictureViewer>{late final PageController controller;late int index;
 @override void initState(){super.initState();index=widget.initialIndex;controller=PageController(initialPage:index);}
 @override void dispose(){controller.dispose();super.dispose();}
 void move(int delta){final next=(index+delta).clamp(0,data.length-1);controller.animateToPage(next,duration:const Duration(milliseconds:260),curve:Curves.easeInOut);}
 @override Widget build(BuildContext context)=>Scaffold(backgroundColor:const Color(0xFFF4FBFA),appBar:AppBar(title:Text('${index+1} / ${data.length}')),body:Stack(children:[PageView.builder(controller:controller,itemCount:data.length,onPageChanged:(v)=>setState(()=>index=v),itemBuilder:(c,i)=>Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text(data[i].picture,style:const TextStyle(fontSize:210)),const SizedBox(height:22),Text(data[i].word,style:const TextStyle(fontSize:30,fontWeight:FontWeight.w900,color:navy))]))),Align(alignment:Alignment.centerLeft,child:IconButton.filledTonal(onPressed:index>0?()=>move(-1):null,icon:const Icon(Icons.arrow_back_ios_new,size:30))),Align(alignment:Alignment.centerRight,child:IconButton.filledTonal(onPressed:index<data.length-1?()=>move(1):null,icon:const Icon(Icons.arrow_forward_ios,size:30)))]));}
class SoundsPage extends StatelessWidget {const SoundsPage({super.key});@override Widget build(BuildContext context){final grouped=<String,List<SoundClip>>{};for(final s in soundClips){grouped.putIfAbsent(s.label,()=>[]).add(s);}final entries=grouped.entries.toList();return Scaffold(appBar:AppBar(title:const Text('الأصوات الحقيقية')),body:ListView.builder(padding:const EdgeInsets.all(12),itemCount:entries.length,itemBuilder:(c,i){final e=entries[i];return Card(color:Colors.white,child:Padding(padding:const EdgeInsets.all(12),child:Row(children:[Text(e.value.first.emoji,style:const TextStyle(fontSize:38)),const SizedBox(width:12),Expanded(child:Text(e.key,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:18,color:navy))),...List.generate(e.value.length,(j)=>Padding(padding:const EdgeInsets.only(left:5),child:OutlinedButton(onPressed:()=>AudioHub.sound(e.value[j].file),child:Text(e.value.length==1?'استمع':'الصوت ${_arabicNumber(j+1)}'))))]))); }));}}
String _arabicNumber(int n)=>['الأول','الثاني','الثالث','الرابع'][min(n-1,3)];
enum QuizKind {letter,word,picture,sound}
class QuizPage extends StatefulWidget {final QuizKind kind;const QuizPage({super.key,required this.kind});@override State<QuizPage> createState()=>_QuizPageState();}
class _QuizPageState extends State<QuizPage>{
 final rnd=Random(); late int target; late List<int> options; late List<String> soundLabels; late Map<String,List<SoundClip>> soundGroups; late SoundClip targetSound; String? feedback; int correctCount=0; bool locked=false; bool pictureAnswersAreLetters=false;
 @override void initState(){super.initState();soundGroups={};for(final clip in soundClips){soundGroups.putIfAbsent(clip.label,()=>[]).add(clip);}soundLabels=soundGroups.keys.toList();_next();}
 String get title=>switch(widget.kind){QuizKind.letter=>'اختبار الحروف',QuizKind.word=>'اختبار الكلمات',QuizKind.picture=>'اختبار الصور',QuizKind.sound=>'اختبار الأصوات'};
 void _next(){if(widget.kind==QuizKind.sound){target=rnd.nextInt(soundLabels.length);final pool=List<int>.generate(soundLabels.length,(i)=>i)..remove(target)..shuffle(rnd);options=([target,...pool.take(3)]..shuffle(rnd));targetSound=soundGroups[soundLabels[target]]![rnd.nextInt(soundGroups[soundLabels[target]]!.length)];}else{target=rnd.nextInt(data.length);final pool=List<int>.generate(data.length,(i)=>i)..remove(target)..shuffle(rnd);options=([target,...pool.take(3)]..shuffle(rnd));}pictureAnswersAreLetters=widget.kind==QuizKind.picture&&rnd.nextBool();feedback=null;locked=false;}
 Future<void> _answer(int v)async{if(locked)return;final ok=v==target;setState((){locked=true;feedback=ok?'أحسنت يا جويرية ⭐':'محاولة جميلة، جربي مرة أخرى';});if(ok){correctCount++;final p=await SharedPreferences.getInstance();await p.setInt('stars',(p.getInt('stars')??0)+1);await AudioHub.praise(correctCount);}else{await AudioHub.say('حاولي مرة أخرى');}}
 @override Widget build(BuildContext context){
  final sound=widget.kind==QuizKind.sound;final item=sound?null:data[target];
  final question=switch(widget.kind){QuizKind.letter=>'اختاري الحرف',QuizKind.word=>'اختاري الكلمة',QuizKind.picture=>pictureAnswersAreLetters?'اختاري الحرف الذي يبدأ به اسم الصورة':'اختاري الكلمة التي تعبّر عن الصورة',QuizKind.sound=>'استمعي للصوت واختاري صورته'};
  
  return Scaffold(appBar:AppBar(title:Text(title)),body:SafeArea(child:Padding(padding:const EdgeInsets.symmetric(horizontal:16,vertical:12),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
   const Spacer(flex:1),
   Text(question,textAlign:TextAlign.center,style:const TextStyle(fontSize:28,fontWeight:FontWeight.w900,color:navy)),
   const SizedBox(height:28),
   if(widget.kind==QuizKind.letter||widget.kind==QuizKind.word) ...[
    IconButton(onPressed:()=>AudioHub.say(widget.kind==QuizKind.letter?item!.name:item!.word),icon:const Icon(Icons.volume_up_rounded,size:100,color:teal)),
   ],
   if(widget.kind==QuizKind.picture)Text(item!.picture,style:const TextStyle(fontSize:180)),
   if(sound) ...[IconButton(onPressed:()=>AudioHub.sound(targetSound.file),icon:const Icon(Icons.volume_up_rounded,size:86,color:teal)),const Text('اضغطي للاستماع مرة أخرى',style:TextStyle(fontSize:15,color:Colors.black54))],
   const SizedBox(height:30),
   if(sound)GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,mainAxisSpacing:14,crossAxisSpacing:14,childAspectRatio:1.35,children:options.map((i){final group=soundGroups[soundLabels[i]]!;return _choice(i,Text(group.first.emoji,style:const TextStyle(fontSize:64)));}).toList())
   else GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,mainAxisSpacing:14,crossAxisSpacing:14,childAspectRatio:2.0,children:options.map((i){final label=switch(widget.kind){QuizKind.letter=>data[i].glyph,QuizKind.word=>data[i].word,QuizKind.picture=>pictureAnswersAreLetters?data[i].glyph:data[i].word,QuizKind.sound=>''};return _choice(i,Text(label,textAlign:TextAlign.center,style:TextStyle(fontSize:widget.kind==QuizKind.letter||pictureAnswersAreLetters?46:29,fontWeight:FontWeight.w900,color:navy)));}).toList()),
   if(feedback!=null)Padding(padding:const EdgeInsets.all(14),child:Text(feedback!,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold,color:teal))),
   FilledButton(onPressed:locked?()=>setState(_next):null,style:FilledButton.styleFrom(minimumSize:const Size(190,54)),child:const Text('السؤال التالي',style:TextStyle(fontSize:19))),const Spacer(flex:1),
  ]))));
 }
 Widget _choice(int value,Widget child)=>FilledButton(onPressed:locked?null:()=>_answer(value),style:FilledButton.styleFrom(backgroundColor:const Color(0xFFDDF2EC),foregroundColor:navy,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(22))),child:child);
}
